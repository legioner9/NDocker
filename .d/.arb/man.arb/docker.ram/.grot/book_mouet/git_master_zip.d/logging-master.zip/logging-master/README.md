# Using Docker Code Examples
## "Logging and Monitoring"

NOTE: It is strongly recommended that you use the "pinned_images" branch rather
than "master" in order to avoid problems with incompatabilities between versions
of the ELK stack and logspout.
